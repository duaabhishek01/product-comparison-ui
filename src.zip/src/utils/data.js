import iphone14Image from '../assets/images/iphone14.jpg';
import samsungs22Image from '../assets/images/galaxys22.jpg';
import oneplus9Image from '../assets/images/oneplus9pro.jpg';
import gpixel6Image from '../assets/images/gpixel6.jpg';
import huaweip30Image from '../assets/images/huaweip30.jpg';
import xiaomi11Image from '../assets/images/xiaomi11pro.jpg';

const products = [
  {
    id: 1,
    name: 'Apple iPhone 14',
    brand: 'Apple',
    image: iphone14Image,
    price: 999,
     rating: 3.7,
    features: {
      ram: '6 GB',
      camera: '12 MP Dual',
      screen: '6.1 inches OLED',
      battery: '3279 mAh',
      processor: 'A15 Bionic',
      resolution: '1170 x 2532',
      refreshRate: '60Hz'
    }
  },
  {
    id: 2,
    name: 'Samsung Galaxy S22',
    brand: 'Samsung',
    image: samsungs22Image,
    price: 799,
    features: {
      ram: '8 GB',
      camera: '50 MP Triple',
      screen: '6.1 inches AMOLED',
      battery: '3700 mAh',
      processor: 'Snapdragon 8 Gen 1',
      resolution: '1080 x 2340',
      refreshRate: '120Hz'
    }
  },
  {
    id: 3,
    name: 'Google Pixel 6',
    brand: 'Google',
    image: gpixel6Image,
    price: 699,
    features: {
      ram: '8 GB',
      camera: '50 MP Dual',
      screen: '6.4 inches OLED',
      battery: '4614 mAh',
      processor: 'Google Tensor',
      resolution: '1080 x 2400',
      refreshRate: '90Hz'
    }
  },
  {
    id: 4,
    name: 'OnePlus 9 Pro',
    brand: 'OnePlus',
    image: oneplus9Image,
    price: 899,
    features: {
      ram: '12 GB',
      camera: '48 MP Quad',
      screen: '6.7 inches Fluid AMOLED',
      battery: '4500 mAh',
      processor: 'Snapdragon 888',
      resolution: '1440 x 3216',
      refreshRate: '120Hz'
    }
  },
  {
    id: 5,
    name: 'Huawei P30 Pro',
    brand: 'Huawei',
    image: huaweip30Image,
    price: 599,
    features: {
      ram: '8 GB',
      camera: '40 MP Quad',
      screen: '6.47 inches OLED',
      battery: '4200 mAh',
      processor: 'Kirin 980',
      resolution: '1080 x 2340',
      refreshRate: '60Hz'
    }
  },
  {
    id: 6,
    name: 'Xiaomi Mi 11',
    brand: 'Xiaomi',
    image: xiaomi11Image,
    price: 499,
    features: {
      ram: '8 GB',
      camera: '108 MP Triple',
      screen: '6.81 inches AMOLED',
      battery: '4600 mAh',
      processor: 'Snapdragon 888',
      resolution: '1440 x 3200',
      refreshRate: '120Hz'
    }
  }
];

export default products;
