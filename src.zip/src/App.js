﻿import React, { useEffect, useRef, useState } from 'react';
import ProductList from './components/ProductList';
import CompareSection from './components/CompareSection';
import products from './utils/data';
import './styles/styles.css';

export default function App() {
  const [compareList, setCompareList] = useState([]);
  const compareSectionRef = useRef(null);

  // Scroll into view after compare section is rendered
  useEffect(() => {
    if (compareList.length === 2 && compareSectionRef.current) {
      // Allow DOM to update before scrolling
      requestAnimationFrame(() => {
        compareSectionRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' });
      });
    }
  }, [compareList]);

  const handleAddToCompare = (product) => {
    const alreadyAdded = compareList.some((p) => p.id === product.id);

    if (alreadyAdded) return;

    if (compareList.length < 3) {
      setCompareList([...compareList, product]);
    } else {
      window.alert('You can only compare up to 3 products.');
    }
  };

  const handleRemoveFromCompare = (product) => {
    setCompareList(compareList.filter((p) => p.id !== product.id));
  };

  return (
    <div className="container">
      <h1 className="page-title">Product Comparison UI</h1>
      <h2 className="section-title">All Mobiles</h2>

      <ProductList
        products={products}
        handleAddToCompare={handleAddToCompare}
        selectedProducts={compareList}
      />

      {compareList.length >= 2 && (
        <div ref={compareSectionRef}>
          <h2 className="section-title">Compare Mobiles</h2>
          <CompareSection
            selectedProducts={compareList}
            handleRemoveFromCompare={handleRemoveFromCompare}
          />
        </div>
      )}
    </div>
  );
}
