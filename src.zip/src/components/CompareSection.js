﻿// CompareSection.js
import React from 'react';

const CompareSection = ({ selectedProducts, handleRemoveFromCompare }) => {
  if (selectedProducts.length === 0) return null;

  // Get all feature keys across all products
  const allFeatures = Array.from(
    new Set(
      selectedProducts.flatMap((product) => Object.keys(product.features))
    )
  );
  const renderStars = (rating) => {
  const fullStars = Math.floor(rating);
  const hasHalfStar = rating % 1 >= 0.25 && rating % 1 < 0.75;
  const emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0);

  const stars = [];

  for (let i = 0; i < fullStars; i++) {
    stars.push(<span key={`full-${i}`} className="star full">★</span>);
  }

  if (hasHalfStar) {
    stars.push(<span key="half" className="star half">⯨</span>); // Unicode half-star alternative
  }

  for (let i = 0; i < emptyStars; i++) {
    stars.push(<span key={`empty-${i}`} className="star empty">☆</span>);
  }

  return stars;
};


  return (
    <div className="compare-section">
      <h2 className="section-title">Compare Mobiles</h2>
      <div className="comparison-table">
        <div className="comparison-row header-row">
          <div className="feature-cell">Models</div>
          {selectedProducts.map((product) => (
            <div className="product-cell" key={product.id}>
              <button className="remove-btn" onClick={() => handleRemoveFromCompare(product)}>×</button>
              <img src={product.image} alt={product.name} className="compare-image" />
              <h3>{product.name}</h3>
            </div>
          ))}
        </div>

        {/* Static fields */}
        <div className="comparison-row">
          <div className="feature-cell">Brand</div>
          {selectedProducts.map((product) => (
            <div className="product-cell" key={product.id + '-brand'}>
              {product.brand}
            </div>
          ))}
        </div>

        <div className="comparison-row">
          <div className="feature-cell">Price</div>
          {selectedProducts.map((product) => (
            <div className="product-cell" key={product.id + '-price'}>
              {product.price}
            </div>
          ))}
        </div>

        <div className="comparison-row">
          <div className="feature-cell">Customer Rating</div>
          {selectedProducts.map((product) => (
            <div key={product.id + '-rating'} className="product-cell">
              {renderStars(product.rating || 0)}
            </div>
          ))}
        </div>


        {/* Dynamic feature rows */}
        {allFeatures.map((featureKey) => (
          <div className="comparison-row" key={featureKey}>
            <div className="feature-cell">
              {featureKey.charAt(0).toUpperCase() + featureKey.slice(1)}
            </div>
            {selectedProducts.map((product) => (
              <div className="product-cell" key={`${product.id}-${featureKey}`}>
                {product.features[featureKey] || '-'}
              </div>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
};

export default CompareSection;
