// ProductList.js
import React, { useState } from 'react';
import ProductCard from './ProductCard';
import CompareSection from './CompareSection';
import products from '../utils/data';

const ProductList = () => {
  const [selectedProducts, setSelectedProducts] = useState([]);

  const handleAddToCompare = (product) => {
    if (selectedProducts.length < 3 && !selectedProducts.includes(product)) {
      setSelectedProducts([...selectedProducts, product]);
    }
  };

  const handleRemoveFromCompare = (product) => {
    setSelectedProducts(selectedProducts.filter((p) => p.id !== product.id));
  };

  return (
   <div>
   <header className="header">
       <h1 className="page-title">Product Comparison UI</h1>
   </header>

<h2 className="section-title">All Mobiles</h2>
      <div className="product-list">
        {products.map((product) => (
          <ProductCard
            key={product.id}
            product={product}
            handleAddToCompare={handleAddToCompare}
            selectedProducts={selectedProducts}
          />
        ))}
      </div>
      {selectedProducts.length >= 2 && (
        <CompareSection
          selectedProducts={selectedProducts}
          handleRemoveFromCompare={handleRemoveFromCompare}
        />
      )}
    </div>
  );
};

export default ProductList;